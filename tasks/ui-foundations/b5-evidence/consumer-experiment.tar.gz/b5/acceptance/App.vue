<script setup lang="ts">
import { reactive, ref } from 'vue';
import { InkButton, InkInput, InkTextarea, InkForm, InkDropdown, InkSwitch, InkPagination, InkTooltip, InkHeader, InkImage, InkLoading, InkDialog, InkPopup, InkDoubleCheck, InkPicker, InkDatetimePickerView, InkAutoForm, InkJsonEditor } from '../../b5-packed/package/dist/index.js';
import '../../b5-packed/package/dist/index.css';
const state = reactive({scenario:'C', loader:refresher, submits:0, clicks:0, text:'original', confirms:[], layout:'col', switch:false, switchErrors:[], chosen:'a', options:undefined, refreshError:false, dialog:false, dialogErrors:[], modeless:false, nested:false, double:0, childAction:0, picked: new Date(2024,0,31,12,30), date: new Date(2024,0,31,0,0), hourFormat:'12', min:undefined,max:undefined,
  form:{name:'existing',zero:0,enabled:false,date:'2024-02-29',extra:'preserve'}, formValidation:{},otherForm:{value:'string'},otherValidation:{},otherSchema:{type:'object',properties:{value:{type:'string',title:'Other value'}}}, jsonA:'{"count":1}',jsonB:'{"name":"B"}', validationA:{},validationB:{}, schemaA:{type:'object',properties:{count:{type:'integer'}},required:['count']}, schemaB:{type:'object',properties:{name:{type:'string'}},required:['name']},
  formSchema:{type:'object',properties:{name:{type:'string',default:'default'},zero:{type:'integer',default:9},enabled:{type:'boolean',default:true},date:{type:'string',format:'date'}},required:['name','zero']}
});
Object.assign(window,{acceptance:state});
function countClick(event: MouseEvent) { if(event instanceof MouseEvent) state.clicks++; }
async function refresher() { if(state.refreshError) throw new Error('load failed'); return [{label:'Alpha',value:'a'},{label:'Beta',value:'b'},{label:'Gamma',value:'c'}]; }
</script>
<template>
  <main>
    <h1>UI foundations</h1>
    <template v-if="state.scenario === 'C'">
      <InkForm :layout="state.layout" @submit="state.submits++">
        <InkInput v-model="state.text" label="Name" name="person" required data-native="input" />
        <InkTextarea :value="state.text" label="Details" required name="details" data-native="textarea" />
        <InkInput v-model="state.text" label="Inline name" type="inline" @confirm="value => state.confirms.push(value)" />
        <InkButton text="Action" @click="countClick" />
        <InkButton text="Submit" native-type="submit" />
        <InkSwitch v-model="state.switch" aria-label="Enabled" @error="error => state.switchErrors.push(String(error))" />
        <InkDropdown v-model="state.chosen" v-model:options="state.options" :refresher="state.loader" label="Choice" enable-stepping />
        <InkPagination :current-page="1" :total-pages="3" />
      </InkForm>
      <InkTooltip content="Helpful detail" v-slot="{describedby}"><InkButton text="Hint" :aria-describedby="describedby" /></InkTooltip>
      <InkLoading />
      <InkHeader title="Brand" />
    </template>
    <template v-if="state.scenario === 'D'">
      <InkButton text="Open dialog" @click="state.dialog = true" />
      <InkButton text="Background" @click="state.clicks++" />
      <InkButton text="Open modeless" @click="state.modeless = true" />
      <InkDialog v-model="state.dialog" title="Edit record" @error="error => state.dialogErrors.push(String(error))"><input aria-label="Dialog input"><InkButton text="Open nested" @click="state.nested = true" /></InkDialog>
      <InkPopup v-model:open="state.nested" aria-label="Nested"><InkButton text="Close nested" @click="state.nested = false" /></InkPopup>
      <InkPopup v-model:open="state.modeless" :scrim="false" aria-label="Modeless"><input aria-label="Modeless input"><InkButton text="Close modeless" @click="state.modeless=false" /></InkPopup>
      <InkDoubleCheck title="Confirm deletion" @confirm="state.double++"><InkButton text="Delete" @click="state.childAction++" /></InkDoubleCheck>
      <InkPicker v-model="state.picked" type="date" label="Due date" />
      <InkDatetimePickerView v-model="state.date" :hour-format="state.hourFormat" :min-date="state.min" :max-date="state.max" />
      <InkImage src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100'%3E%3Crect width='100' height='100' fill='blue'/%3E%3C/svg%3E" alt="Blue square" />
    </template>
    <template v-if="state.scenario === 'E'">
      <InkAutoForm v-model:form-data="state.form" :schema="state.formSchema" @validation="state.formValidation = $event" />
      <InkAutoForm v-model:form-data="state.otherForm" :schema="state.otherSchema" @validation="state.otherValidation=$event" />
      <InkJsonEditor v-model="state.jsonA" label="JSON A" :schema="state.schemaA" @validation="state.validationA=$event" />
      <InkJsonEditor v-model="state.jsonB" label="JSON B" :schema="state.schemaB" @validation="state.validationB=$event" />
      <InkButton text="Save JSON" :disabled="!state.validationA.valid" @click="state.clicks++" />
    </template>
    <pre id="state">{{ state }}</pre>
  </main>
</template>
<style>body{margin:24px;font-family:system-ui;background:var(--sys-color-surface-base);color:var(--sys-color-text-base)}main{max-width:900px}form{max-width:550px}#state{font-size:12px}.ink-datetime-picker-view{max-width:800px}</style>
