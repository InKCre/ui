import {chromium} from '/Volumes/WorkSSD/Development/InKCre/client-web/node_modules/.pnpm/playwright@1.61.1/node_modules/playwright/index.mjs';
import {mkdirSync,writeFileSync} from 'node:fs';
const out=new URL('./results/',import.meta.url);mkdirSync(out,{recursive:true});
const report={};const browser=await chromium.launch();report.chromium=browser.version();const page=await browser.newPage({viewport:{width:1000,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
const url=(view='form',mode='production',width=480,theme='light')=>`http://127.0.0.1:5199/tmp/b5/index.html?view=${view}&mode=${mode}&width=${width}&theme=${theme}`;
async function load(view,mode,width,theme){await page.goto(url(view,mode,width,theme));await page.waitForSelector('main');await page.addStyleTag({content:'*{transition:none!important;animation:none!important}'});}
const shot=name=>page.screenshot({path:new URL(name+'.png',out).pathname,fullPage:true});
function dimensions(){const rect=e=>{let r=e.getBoundingClientRect(),s=getComputedStyle(e);return {width:r.width,height:r.height,font:s.fontSize,line:s.lineHeight,family:s.fontFamily,gap:s.gap,overflowX:e.scrollWidth-e.clientWidth}};return {width:innerWidth,main:rect(document.querySelector('main')),pageOverflow:document.documentElement.scrollWidth-innerWidth,fields:[...document.querySelectorAll('.ink-field')].map(e=>({box:rect(e),label:rect(e.querySelector('.ink-field__label')),error:e.querySelector('.ink-field__error')?rect(e.querySelector('.ink-field__error')):null})),input:[...document.querySelectorAll('.ink-input')].map(rect),button:[...document.querySelectorAll('.ink-button')].map(rect)}}
report.forms=[];
for(const mode of ['production'])for(const width of [320,480,800]){
 await load('form',mode,width);report.forms.push({mode,width,metrics:await page.evaluate(dimensions)});
 if(width===320)await shot(`form-${mode}-320`);
}
report.geometry=[];
for(const mode of ['production'])for(const root of [16]){
 await load('controls',mode,480);await page.evaluate(root=>document.documentElement.style.fontSize=root+'px',root);
 const measure=()=>page.locator('.ink-switch').evaluateAll(els=>els.map(e=>{const r=e.getBoundingClientRect(),h=e.querySelector('.ink-switch__handle').getBoundingClientRect(),l=e.querySelector('.ink-switch__label').getBoundingClientRect();return {name:e.getAttribute('aria-label'),w:r.width,h:r.height,label:l.width,handle:h.width,clips:l.left<h.left-.5||l.right>h.right+.5||l.top<h.top-.5||l.bottom>h.bottom+.5,escapes:h.right>r.right+.5||h.left<r.left-.5}}));
 const off=await measure();await page.evaluate(()=>b4.toggle=true);await page.waitForTimeout(30);const on=await measure();report.geometry.push({mode,root,off,on});await shot(`controls-${mode}-${root}`);
}
report.probes=[];
for(const mode of ['production']){
 await load('probes',mode,480);
 const read=()=>page.locator('[class^=probe-]').evaluateAll(els=>els.map(e=>{const s=getComputedStyle(e);return {name:e.className,font:s.fontSize,line:s.lineHeight,family:s.fontFamily,spacing:s.letterSpacing,decoration:s.textDecorationLine,padding:s.padding}}));
 report.probes.push({mode,before:await read()});
 await page.evaluate(()=>{let s=document.documentElement.style;s.setProperty('--sys-space-md','24px');s.setProperty('--sys-typo-family-sans','Georgia, serif');s.setProperty('--sys-typo-family-mono','Courier New, monospace');s.setProperty('--sys-font-label-lg-font-size','20px');s.setProperty('--sys-font-label-lg-line-height','1.5')});report.probes.push({mode,override:await read()});await shot(`probes-${mode}`);
}
function paint(e){const s=getComputedStyle(e);return {fg:s.color,bg:s.backgroundColor,border:s.borderColor,outline:s.outline,offset:s.outlineOffset,opacity:s.opacity}}
report.colors=[];
for(const theme of ['light','dark']){
 for(const mode of ['production']){
  await load('overlay',mode,480,theme);await page.getByRole('combobox',{name:'保存位置',exact:true}).focus();await page.keyboard.press('ArrowDown');
  const option=page.getByRole('option').first();report.colors.push({theme,mode,kind:'selected-keyboard',option:await option.evaluate(paint),description:await option.locator('.option__description').evaluate(paint)});await shot(`selected-${mode}-${theme}`);
  await option.hover();report.colors.push({theme,mode,kind:'selected-hover',option:await option.evaluate(paint),description:await option.locator('.option__description').evaluate(paint)});
  await page.keyboard.press('Escape');await page.getByRole('button',{name:'删除工作空间',exact:true}).click();report.colors.push({theme,mode,kind:'confirmation',title:await page.locator('.ink-double-check__title').evaluate(paint),surface:await page.locator('.ink-double-check__dialog').evaluate(paint)});await shot(`confirm-${mode}-${theme}`);await page.keyboard.press('Escape');
 }
 await load('controls','production',480,theme);
 for(const kind of ['primary','subtle','danger']){
  const b=page.locator(`[data-button=${kind}]`);await page.mouse.move(0,0);const normal=await b.evaluate(paint);await b.hover();const hover=await b.evaluate(paint);await page.mouse.down();const pressed=await b.evaluate(paint);await page.mouse.up();await page.mouse.move(0,0);await page.locator('body').click({position:{x:0,y:0}});await b.focus();await page.keyboard.press('Tab');await page.keyboard.press('Shift+Tab');const focus=await b.evaluate(paint);
  const disabled=page.locator(`[data-theme-row=${kind}] button:disabled`).first(),pending=page.locator(`[data-theme-row=${kind}] button:disabled`).last();await page.mouse.move(0,0);const disabledBefore=await disabled.evaluate(paint);await disabled.hover();const disabledHover=await disabled.evaluate(paint);await pending.hover();const loading=await pending.evaluate(paint);report.colors.push({theme,kind,normal,hover,pressed,focus,disabledBefore,disabledHover,loading});
 }
 report.colors.push({theme,kind:'feedback',paints:await page.locator('.feedback').evaluateAll(els=>els.map(e=>({name:e.className,fg:getComputedStyle(e).color,bg:getComputedStyle(e).backgroundColor})))});await page.mouse.move(0,0);await shot(`states-${theme}`);
 await load('form','production',320,theme);await page.locator('input').first().focus();report.colors.push({theme,kind:'error-focus',input:await page.locator('.ink-input').first().evaluate(paint),text:await page.locator('.ink-field__error').first().evaluate(paint)});await shot(`error-focus-${theme}`);
}
report.spacing=[];
for(const width of [320,800]){await load('spacing','production',width);report.spacing.push({width,values:await page.locator('.list-page').evaluateAll(els=>els.map(e=>({kind:e.className,width:e.clientWidth,padding:getComputedStyle(e).padding,overflow:e.scrollWidth-e.clientWidth,content:e.clientWidth-2*parseFloat(getComputedStyle(e).paddingLeft)})))});await shot(`spacing-${width}`)}
for(const width of [320,800]){await load('hierarchy','production',width);await shot(`hierarchy-${width}`)}
report.images=[];
for(const mode of ['production'])for(const which of ['明亮背景图片','复杂明暗图片']){await load('overlay',mode,320);await page.getByRole('button',{name:which,exact:true}).click();const title=page.locator('.ink-image__expanded-title:visible');report.images.push({mode,which,paint:await title.evaluate(paint),metrics:await title.evaluate(e=>({w:e.clientWidth,scroll:e.scrollWidth,h:e.clientHeight,whitespace:getComputedStyle(e).whiteSpace}))});await shot(`image-${mode}-${which==='明亮背景图片'?'bright':'mixed'}`);}
await load('overlay','production',320,'dark');await page.evaluate(()=>{const s=document.documentElement.style;s.setProperty('--sys-space-md','24px');s.setProperty('--sys-typo-family-sans','Georgia, serif');s.setProperty('--sys-font-label-lg-font-size','20px')});await page.getByRole('button',{name:'打开浮层',exact:true}).click();report.teleport=await page.getByRole('dialog').filter({visible:true}).evaluate(e=>({parent:e.parentElement.tagName,theme:getComputedStyle(e).colorScheme,padding:[...e.querySelectorAll('[class*=probe-space]')].map(n=>getComputedStyle(n).padding),font:[...e.querySelectorAll('[class*=probe-space]')].map(n=>getComputedStyle(n).font),localAncestor:!!e.closest('.local-override')}));await shot('override-popup');
report.errors=errors;await browser.close();
writeFileSync(new URL('basic-measurements.json',out),JSON.stringify(report,null,2));console.log('Chromium experiments recorded.');