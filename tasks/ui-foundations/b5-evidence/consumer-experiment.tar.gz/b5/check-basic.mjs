import {readFileSync,writeFileSync} from 'node:fs';import assert from 'node:assert/strict';
const dir=new URL('./results/',import.meta.url);const r=JSON.parse(readFileSync(new URL('basic-measurements.json',dir)));const rows=[];
const rgb=s=>s.match(/[\d.]+/g).slice(0,3).map(Number);const lum=c=>c.map(v=>v/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4).reduce((a,v,i)=>a+v*[.2126,.7152,.0722][i],0);const contrast=(a,b)=>{const l=[lum(rgb(a)),lum(rgb(b))].sort((a,b)=>b-a);return(l[0]+.05)/(l[1]+.05)};
for(const x of r.colors){
 if(x.mode==='baseline')continue;
 if(x.description){const ratio=contrast(x.description.fg,x.option.bg);assert.ok(ratio>=4.5);rows.push({theme:x.theme,kind:x.kind,ratio});}
 if(x.title){const ratio=contrast(x.title.fg,x.surface.bg);assert.ok(ratio>=4.5);rows.push({theme:x.theme,kind:x.kind,ratio});}
 if(x.normal){for(const state of ['normal','hover','pressed','loading']){const ratio=contrast(x[state].fg,x[state].bg);assert.ok(ratio>=4.5);rows.push({theme:x.theme,kind:x.kind,state,ratio})}assert.deepEqual(x.disabledBefore,x.disabledHover);assert.match(x.focus.outline,/solid 2px/);}
 if(x.paints)for(const p of x.paints){const ratio=contrast(p.fg,p.bg);assert.ok(ratio>=4.5);rows.push({theme:x.theme,kind:p.name,ratio})}
 if(x.kind==='error-focus'){const bg=x.theme==='dark'?'rgb(71,71,71)':'rgb(255,255,255)';assert.ok(contrast(x.text.fg,bg)>=4.5);assert.match(x.input.outline,/solid 2px/)}
}
for(const x of r.forms.filter(x=>x.mode==='production')){assert.equal(x.metrics.main.overflowX,0);for(const f of x.metrics.fields)assert.equal(f.box.overflowX,0)}
for(const x of r.geometry.filter(x=>x.mode==='production')){for(const s of [...x.off,...x.on])assert.ok(!s.clips&&!s.escapes);assert.deepEqual(x.off.map(s=>s.w),x.on.map(s=>s.w))}
const a=r.probes.find(x=>x.mode==='production'&&x.override).override;for(const key of ['font','line','family','spacing','decoration'])assert.equal(a[0][key],a[1][key]);for(const key of ['font','line','family','spacing','decoration'])assert.equal(a[1][key],a[2][key]);assert.deepEqual(a.filter(x=>x.name.startsWith('probe-space')).map(x=>x.padding),['24px','24px','24px']);assert.deepEqual(r.teleport.padding,['24px','24px','24px']);assert.equal(r.teleport.localAncestor,false);assert.deepEqual(r.errors,[]);
writeFileSync(new URL('basic-contrast.json',dir),JSON.stringify(rows,null,2));console.log('Recorded geometry, foreground pairs, keyboard focus, disabled precedence and packed output parity passed.');
