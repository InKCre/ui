import {createRequire} from 'node:module';
import {writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const require=createRequire(new URL('../../package.json',import.meta.url));
const sass=require('sass');
const {createGenerator,presetWind3}=require('unocss');
const {default:presetInk}=await import('../b5-packed/package/dist/uno/preset-ink.js');
const root=fileURLToPath(new URL('../b5-packed/package/styles/',import.meta.url));
const roles=['label-lg','label-md','body-sm','body-md','body-lg','title-sm','title-lg','headline-lg'];
const sassCss=sass.compileString(`@use 'mixins' as m; @use 'functions' as f;
.probe-font-sass{@include m.apply-font(label-lg)}
.probe-underline-sass{@include m.apply-font(label-lg,$underlined:true)}
.probe-mono-sass{@include m.apply-font(label-lg,$mono:true)}
.probe-space-sass{padding:f.sys-var(space,md)}
${roles.map(role=>`.role-${role}{@include m.apply-font(${role})}`).join('\n')}`,{loadPaths:[root]}).css;
const uno=await createGenerator({presets:[presetWind3(),presetInk()]});
const mappings={'font-label-lg':'probe-font-uno','font-label-lg-underlined':'probe-underline-uno','font-label-lg-mono':'probe-mono-uno','p-md':'probe-space-uno'};
let css='';for(const [name,selector] of Object.entries(mappings)){
 const result=await uno.generate(name,{preflights:false});css+=result.css.replaceAll('.'+name,'.'+selector)+'\n';
}
css+=(await uno.generate('font-label-lg font-mono underline font-title-lg font-body-md font-body-sm text-feedback-success text-feedback-error bg-surface-subtle p-md',{preflights:false})).css;
writeFileSync(new URL('./probes.css',import.meta.url),sassCss+'\n'+css+`\n.probe-font-css{font-family:var(--sys-typo-family-sans);font-size:var(--sys-font-label-lg-font-size);font-weight:var(--sys-font-label-lg-font-weight);line-height:var(--sys-font-label-lg-line-height);letter-spacing:var(--sys-font-label-lg-letter-spacing);text-decoration:none}.probe-space-css{padding:var(--sys-space-md)}${['error','success','warning','info'].map(kind=>`.feedback.${kind}{color:var(--sys-color-feedback-${kind})}`).join('')}`);
