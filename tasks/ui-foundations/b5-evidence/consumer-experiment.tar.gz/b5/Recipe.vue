<script setup lang="ts">
import { ref } from "vue";
import { InkForm, InkInput, InkButton } from "../b5-packed/package/dist/index.js";
// 宿主提供实际持久化函数，失败时 reject。
const props = defineProps<{ save: (name: string) => Promise<void> }>();
const name = ref(""), error = ref(""), result = ref(""), pending = ref(false);
async function submit() {
  if (pending.value) return;
  error.value = name.value.trim() ? "" : "请输入名称。";
  result.value = "";
  if (error.value) return;
  pending.value = true;
  try { await props.save(name.value.trim()); result.value = "设置已保存。"; }
  catch { error.value = "保存失败，请稍后重试。"; }
  finally { pending.value = false; }
}
</script>
<template>
  <h1 class="font-title-lg">工作空间设置</h1>
  <p class="font-body-md">修改团队看到的工作空间名称。</p>
  <InkForm layout="col" @submit="submit">
    <InkInput v-model="name" label="名称" name="workspace" :error="error" required />
    <InkButton theme="primary" native-type="submit" text="保存设置" :is-loading="pending" />
    <p v-if="result" role="status" class="font-body-sm bg-surface-subtle text-feedback-success p-md">{{ result }}</p>
  </InkForm>
</template>