import {spawn} from 'node:child_process';import {mkdtempSync,writeFileSync} from 'node:fs';import {connect} from './marionette.mjs';
const profile=mkdtempSync('/tmp/inkcre-b4-firefox-');writeFileSync(profile+'/user.js','user_pref("marionette.port", 2830);user_pref("browser.shell.checkDefaultBrowser", false);user_pref("browser.zoom.siteSpecific", false);');
const child=spawn('/Users/lanzhijiang/Library/Caches/ms-playwright/firefox-1532/firefox/Nightly.app/Contents/MacOS/firefox',['--headless','--no-remote','--profile',profile,'--marionette','--remote-allow-system-access'],{env:{...process.env,MOZ_HEADLESS_WIDTH:'1000',MOZ_HEADLESS_HEIGHT:'1000'},stdio:['ignore','pipe','pipe']});
child.stderr.on('data',x=>process.stderr.write(x));await new Promise(r=>setTimeout(r,3000));
try{
 const {command,close}=await connect(2830);await command('WebDriver:NewSession',{capabilities:{alwaysMatch:{acceptInsecureCerts:true}}});
 const js=async script=>(await command('WebDriver:ExecuteScript',{script,args:[],newSandbox:true,sandbox:'default'})).value;
 const go=async view=>{await command('WebDriver:Navigate',{url:'http://127.0.0.1:5199/tmp/b4/index.html?width=320&view='+view});await new Promise(r=>setTimeout(r,600));};
 const zoom=async (value,full=false)=>{await command('Marionette:SetContext',{value:'chrome'});const v=await js(`Services.prefs.setBoolPref('browser.zoom.full',${full});ZoomManager.setZoomForBrowser(gBrowser.selectedBrowser,${value});return {text:gBrowser.selectedBrowser.textZoom,full:gBrowser.selectedBrowser.fullZoom};`);await command('Marionette:SetContext',{value:'content'});return v;};
 const report={};
 const element=async selector=>Object.values((await command("WebDriver:FindElement",{using:"css selector",value:selector})).value)[0];await go('probes');const metric="const e=document.querySelector('#px-sentinel');return {font:getComputedStyle(e).fontSize,height:e.getBoundingClientRect().height,box:document.querySelector('#box-sentinel').getBoundingClientRect().width,viewport:innerWidth,root:getComputedStyle(document.documentElement).fontSize};";
 report.before=await js(metric);report.native=await zoom(2);report.after=await js(metric);console.log(report);
 for(const view of ['form','controls','overlay']){
 await zoom(1);await go(view);await zoom(2);await js("document.querySelectorAll('*').forEach(e=>{e.style.transition='none';e.style.animation='none'});return true;");
 report[view]=await js("return {viewport:innerWidth,overflow:document.documentElement.scrollWidth-innerWidth,mainOverflow:document.querySelector('main').scrollWidth-document.querySelector('main').clientWidth,fonts:[...document.querySelectorAll('.ink-input__input,.ink-button,.ink-switch__label')].map(e=>({name:e.className,font:getComputedStyle(e).fontSize,h:e.getBoundingClientRect().height,w:e.getBoundingClientRect().width}))};");
 if(view==='form'){const id=await element('input');await command('WebDriver:ElementClear',{id});await command('WebDriver:ElementSendKeys',{id,text:'Team 200%'});await command('WebDriver:ElementClick',{id:await element('button[type=submit]')});report.form.submitResult=await js('return document.querySelector("[role=status]").textContent;');}
 if(view==='controls'){await command('WebDriver:ElementClick',{id:await element('[role=switch]')});report.controls.checked=await js('return document.querySelector("[role=switch]").getAttribute("aria-checked");');}
 const image=await command('WebDriver:TakeScreenshot',{id:null,full:true,scroll:false});writeFileSync(new URL('./results/firefox-text200-'+view+'.png',import.meta.url),Buffer.from(image.value,'base64'));
 }
 await zoom(1);await go('probes');report.pageZoom=await zoom(2,true);report.pageZoomMetrics=await js(metric);
 await zoom(1);await go('form');await zoom(2,true);report.pageZoomForm=await js('return {viewport:innerWidth,overflow:document.documentElement.scrollWidth-innerWidth};');
 writeFileSync(new URL('./results/firefox.json',import.meta.url),JSON.stringify(report,null,2));await command('WebDriver:DeleteSession');close();
}finally{child.kill('SIGTERM')}
