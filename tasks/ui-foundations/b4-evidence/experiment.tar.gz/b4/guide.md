# B4 候选指南：设置页走读输入

这是待 B5 迁移的设计方案。实验中的 role-* 类仅由 candidate.scss 提供，当前安装包没有 body-md/body-sm/title-lg 的正式输出。不要将临时类发布为新 API。

在正式消费页从 @inkcre/ui-web 导入组件并加载 @inkcre/ui-web/styles。宿主为自己的 body 设置 text.base 前景和 surface.base 背景。使用 InkForm layout="col"，InkInput v-model、label、name、required、error；Input 自己生成 label/error 关联，不再嵌套一个重复标签的 InkField。外置帮助文字通过 aria-describedby 指向明确的 id。Textarea 的模型为 v-model:value。

页面标题选 title-lg（28/36），段落选 body-md（16/24），字段帮助和错误选 body-sm（14/20）。标签、按钮仍用默认 label-lg（14/20）；简短元数据可以 label-md（12/16）。按用途选角色，不能因为它们同值就相互替换。

主提交按钮显式写 theme="primary"、native-type="submit"。普通按钮原生类型默认为 button，视觉主题默认为 subtle。危险动作显式写 theme="danger"。Form 的 submit 处理由宿主管理，原生 required 校验先于提交；服务器错误通过字段 error 或有明确文字的错误反馈呈现。成功反馈使用 feedback.success 前景，surface.subtle 背景和 role="status"；不要只靠颜色表达结果。

mono 是技术 ID/代码的字体选择；underline 是装饰选择。根级字体、主题、共享间距可以走明确的运行时入口，局部 wrapper 的变量不穿过 Teleport。页面默认留白先用 16px；宽主区有需要再由宿主明确选 32px。不要创造全局 density 或把所有空间改成 em。

本次按安装包已有组件说明与本页完成 Recipe.vue，已做原生提交、成功消息和服务器失败走读。执行者事先参与过源码维护，结果不等于独立 AI 的盲测，也不证明尚未生成的正式字体输出可消费。
