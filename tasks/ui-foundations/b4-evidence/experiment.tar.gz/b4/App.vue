<script setup>
import {reactive,onMounted} from 'vue';
import {InkForm,InkInput,InkTextarea,InkButton,InkSwitch,InkDropdown,InkPicker,InkPagination,InkDoubleCheck,InkPopup,InkImage} from '../packed/package/dist/index.js';
import '../packed/package/dist/index.css';
import './candidate.scss';
import './probes.css';
import Recipe from './Recipe.vue';
const q = new URLSearchParams(location.search);
document.documentElement.classList.toggle('candidate',q.get('mode')!=='baseline');
document.documentElement.dataset.theme=q.get('theme')||'light';
const s=reactive({width:Number(q.get('width'))||480,view:q.get('view')||'form',text:'我的工作空间 / Personal workspace',note:'通知会发送到此工作空间。Changes apply to future jobs.',error:'请输入有效的名称。Use a descriptive name so that your teammates can identify this workspace. 不应遗漏错误信息。',choice:'local',toggle:false,popup:false,submits:0,result:'',pending:false});
window.b4=s;
onMounted(()=>{if(!document.documentElement.classList.contains('candidate'))return;for(const el of document.querySelectorAll('.ink-switch')){const name=el.getAttribute('aria-label');for(const text of (name==='通知'?['已开启','已关闭']:name==='English state'?['Enabled','Disabled']:['ON','OFF'])){const span=document.createElement('span');span.textContent=text;span.className='b4-switch-sizer';span.setAttribute('aria-hidden','true');el.append(span)}}});
const options=[{label:'本地工作空间 Local workspace',value:'local',description:'已选择的工作空间，将保存设置并同步后续任务。Selected workspace for future jobs.'},{label:'远程工作空间 Remote workspace',value:'remote',description:'需要网络连接，可以稍后重试。Connection required.'}];
const svg=(mixed)=>'data:image/svg+xml,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="900" height="500"><rect width="900" height="500" fill="white"/>${mixed?'<rect width="450" height="500" fill="#111"/><circle cx="680" cy="240" r="150" fill="#e0c967"/>':''}</svg>`);
function save(){s.submits++;s.result=s.text.trim()?'success':'error'}
</script>
<template>
<main :style="{width:s.width+'px'}">
  <Recipe v-if="s.view==='recipe'"/>
  <template v-if="s.view==='form'">
    <h1 class="role-title-lg">工作空间设置</h1><p class="role-body-md">管理工作空间的名称、任务和通知。Choose how this workspace works for your team.</p>
    <InkForm layout="col" @submit="save">
      <InkInput v-model="s.text" label="工作空间名称：请使用团队成员能够识别的名称 Workspace display name used by all team members" name="workspace" :error="s.error" required />
      <InkInput v-model="s.text" :label="'workspace_identifier_'+ 'abcdefghijklmnop'.repeat(4)" />
      <InkTextarea v-model:value="s.note" label="补充说明 Additional details" :error="s.error" />
      <InkDropdown v-model="s.choice" :options="options" label="保存位置" />
      <InkPicker :model-value="null" type="date" display-value-as="box" label="生效日期" />
      <div class="actions"><InkButton text="保存工作空间设置 Save workspace settings" theme="primary" native-type="submit"/><InkButton theme="subtle" text="取消"/></div>
      <p v-if="s.result" :class="'feedback '+s.result" role="status">{{s.result==='success'?'已保存设置 Settings saved':'保存失败，请填写名称 Save failed: enter a name'}}</p>
    </InkForm>
  </template>
  <template v-if="s.view==='controls'">
    <h1 class="role-title-lg">操作与状态</h1>
    <section v-for="theme in ['primary','subtle','danger']" :key="theme" :data-theme-row="theme"><p class="role-body-sm">{{theme}}</p><div class="actions"><InkButton :theme="theme" text="执行操作" :data-button="theme" @click="s.submits++"/><InkButton :theme="theme" text="不可用" disabled/><InkButton :theme="theme" text="保存中" is-loading/></div></section>
    <div class="actions"><InkButton text="添加任务" icon="i-mdi-refresh"/><InkButton aria-label="添加" icon="i-mdi-refresh" type="square"/><InkButton aria-label="更多" icon="i-mdi-menu" type="square" size="sm"/></div>
    <InkPagination :current-page="1" :total-pages="8"/>
    <div class="actions switches"><InkSwitch v-for="size in ['xs','sm','md','lg']" :key="size" :size="size" v-model="s.toggle" :aria-label="size" /></div>
    <div class="actions"><InkSwitch v-model="s.toggle" size="xs" on-text="已开启" off-text="已关闭" aria-label="通知"/><InkSwitch v-model="s.toggle" size="xs" on-text="Enabled" off-text="Disabled" aria-label="English state"/></div>
    <div v-for="kind in ['success','warning','info','error']" :key="kind" :class="'feedback '+kind">{{ {success:'已完成 · 连接正常',warning:'等待中 · 网络不稳定',info:'正在运行 · 正在连接',error:'执行失败 · 连接中断'}[kind] }}</div>
  </template>
  <template v-if="s.view==='overlay'">
    <h1 class="role-title-lg">浮层与选中项</h1>
    <InkDropdown v-model="s.choice" :options="options" label="保存位置" />
    <div class="actions"><InkDoubleCheck title="删除工作空间？此操作需要确认。"><InkButton theme="danger" text="删除工作空间"/></InkDoubleCheck><InkButton text="打开浮层" @click="s.popup=true"/></div>
    <div class="local-override" style="--sys-space-md:48px"><InkPopup v-model:open="s.popup" aria-label="覆盖实验"><div class="probe-space-css role-body-md">根主题与字体</div><div class="probe-space-sass role-label-lg">Sass</div><div class="probe-space-uno role-label-lg">Uno</div><InkButton text="关闭" @click="s.popup=false"/></InkPopup></div>
    <div class="images"><InkImage :src="svg(false)" alt="明亮背景图片" title="明亮背景上的图片标题 Bright image title"/><InkImage :src="svg(true)" alt="复杂明暗图片" title="复杂明暗图片的完整标题 — 中文与 English words should remain available"/></div>
  </template>
  <template v-if="s.view==='hierarchy'">
    <article v-for="size in [22,28,36]" :key="size" class="hierarchy"><h1 :style="{fontSize:size/16+'rem',lineHeight:({22:28,28:36,36:48}[size])/size}">连接的设备 Connected peers</h1><p :style="{fontSize:({22:14,28:16,36:18}[size])/16+'rem',lineHeight:({22:20,28:24,36:24}[size])/({22:14,28:16,36:18}[size])}">管理设备连接，查看同步状态。Connect your workspace and keep recent jobs available.</p><div class="card"><h2 class="role-title-sm">我的工作站</h2><p class="role-body-sm">最后连接于几分钟前。可在设备设置中查看连接日志和任务详情。</p><span class="role-label-md">workstation_01 · 在线</span></div></article>
  </template>
  <template v-if="s.view==='spacing'">
    <div v-for="kind in ['viewport','fixed16','fixed32','bounded']" :key="kind" class="host"><article :class="'list-page '+kind"><span class="role-label-md">{{kind}} · INFORMATION BASE</span><h1 class="role-headline-lg">知识库 Information base</h1><p class="role-body-md">搜索已保存的内容，继续上次的工作。</p><div class="search"><InkInput placeholder="搜索知识库"/><InkButton text="搜索"/></div><div class="card role-body-sm">最近更新的文档<br>会议记录与任务计划</div></article></div>
  </template>
  <template v-if="s.view==='probes'">
    <div class="hostile" style="font-family:serif;letter-spacing:3px;text-decoration:underline">
      <p v-for="entry in ['css','sass','uno']" :key="entry" :class="'probe-font-'+entry">相同角色 Same label</p>
      <p class="probe-underline-sass">Sass underline</p><p class="probe-underline-uno">Uno underline</p><p class="probe-mono-sass">id_01=abc</p><p class="probe-mono-uno">id_01=abc</p>
    </div>
    <div class="probe-space-css">CSS space</div><div class="probe-space-sass">Sass space</div><div class="probe-space-uno">Uno space</div>
    <span id="px-sentinel" style="font-size:13px;line-height:normal">固定像素 Text zoom sentinel</span><div id="box-sentinel" style="width:100px;height:20px;background:#999"></div>
  </template>
</main>
</template>
<style>
body{margin:0;padding:24px;font-family:system-ui;background:var(--sys-color-surface-base);color:var(--sys-color-text-base)}main{max-width:100%;margin:auto}h1,h2,p{margin:0 0 16px}section,.hierarchy{margin-bottom:24px}.actions{display:flex;flex-wrap:wrap;gap:16px;margin:16px 0;align-items:center}.actions>*{max-width:100%}.feedback,.card{padding:16px;margin:16px 0;background:var(--sys-color-surface-subtle)}.images{display:flex;gap:16px;margin:32px 0}.images>.ink-image{width:45%}.host{container-type:inline-size;margin:24px 0;border:1px dashed #777}.list-page{box-sizing:border-box}.list-page.viewport{padding:clamp(48px,9vw,112px) clamp(24px,7vw,96px)}.list-page.fixed16{padding:16px}.list-page.fixed32{padding:32px}.list-page.bounded{padding:clamp(16px,4cqi,32px)}.search{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px}.hierarchy h1{font-weight:400}.role-label-md{font-size:.75rem;line-height:1.333333}.role-label-lg,.role-body-sm{font-size:.875rem;line-height:1.428571}.role-body-md{font-size:1rem;line-height:1.5}.role-title-sm{font-size:1.375rem;line-height:1.272727;font-weight:400}.role-title-lg{font-size:1.75rem;line-height:1.285714;font-weight:400}.role-headline-lg{font-size:2.25rem;line-height:1.333333;font-weight:400}
</style>
