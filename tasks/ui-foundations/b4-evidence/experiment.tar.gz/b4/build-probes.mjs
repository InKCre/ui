import {createRequire} from 'node:module';
import {writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const require=createRequire(new URL('../../package.json',import.meta.url));
const sass=require('sass');
const {createGenerator}=require('unocss');
const {default:presetInk}=await import('../packed/package/dist/uno/preset-ink.js');
const root=fileURLToPath(new URL('../packed/package/styles/',import.meta.url));
const baselineSass=sass.compileString(`@use 'mixins' as m; html:not(.candidate){.probe-font-sass{@include m.apply-font(label-lg)}.probe-underline-sass{@include m.apply-font(label-lg-underlined)}.probe-mono-sass{@include m.apply-font(label-lg,true)}}`,{loadPaths:[root]}).css;
const baseline=await createGenerator({presets:[presetInk()]});
const mappings={'font-label-lg':'probe-font-uno','font-label-lg-underlined':'probe-underline-uno','font-label-lg-mono':'probe-mono-uno','p-md':'probe-space-uno'};
let uno='';
for(const [name,selector] of Object.entries(mappings)){
 const {css}=await baseline.generate(name,{preflights:false});
 uno+=css.replaceAll('.'+name,'html:not(.candidate) .'+selector)+'\n';
}
const typography=(mono=false,underline=false)=>({'font-family':`var(--sys-typo-family-${mono?'mono':'sans'})`,'font-size':'var(--sys-font-label-lg-font-size)','line-height':'var(--sys-font-label-lg-line-height)','font-weight':'400','letter-spacing':'0','text-decoration':underline?'underline':'none'});
const candidate=await createGenerator({presets:[],rules:[['probe-font-uno',typography()],['probe-mono-uno',typography(true)],['probe-underline-uno',typography(false,true)],['probe-space-uno',{padding:'var(--sys-space-md)'}]]});
let {css}=await candidate.generate('probe-font-uno probe-mono-uno probe-underline-uno probe-space-uno',{preflights:false});
css=css.replace(/\.probe-/g,'html.candidate .probe-');
writeFileSync(new URL('./probes.css',import.meta.url),baselineSass+'\n'+uno+'\n'+css+`\n.probe-font-css{font-size:var(--sys-font-label-lg-font-size);font-weight:400;line-height:var(--sys-font-label-lg-line-height);letter-spacing:0;text-decoration:none}.candidate .probe-font-css{font-family:var(--sys-typo-family-sans)}.probe-space-css,.probe-space-sass{padding:var(--sys-space-md)}`);
