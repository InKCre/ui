<script setup>
import {ref} from 'vue';
import {InkForm,InkInput,InkButton} from '../packed/package/dist/index.js';
const name=ref('我的工作空间'),error=ref(''),result=ref('');
function save(){error.value=name.value==='fail'?'保存失败，请稍后重试。':'';result.value=error.value?'':'设置已保存。'}
</script>
<template><h1 class="role-title-lg">工作空间设置</h1><p class="role-body-md">修改团队看到的工作空间名称。</p><InkForm layout="col" @submit="save"><div><InkInput v-model="name" label="名称" name="workspace" :error="error" required aria-describedby="name-help"/><p id="name-help" class="role-body-sm">使用团队成员能够识别的名称。</p></div><InkButton theme="primary" native-type="submit" text="保存设置"/><p v-if="result" class="feedback success" role="status">{{result}}</p></InkForm></template>
