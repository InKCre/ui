import net from 'node:net';
export async function connect(port){
 const socket=net.connect(port,'127.0.0.1');let buffer=Buffer.alloc(0),messages=[],listeners=[];
 socket.on('data',chunk=>{buffer=Buffer.concat([buffer,chunk]);for(;;){const colon=buffer.indexOf(':');if(colon<0)return;const length=Number(buffer.subarray(0,colon).toString());if(buffer.length<colon+1+length)return;const value=JSON.parse(buffer.subarray(colon+1,colon+1+length).toString());buffer=buffer.subarray(colon+1+length);if(listeners.length)listeners.shift()(value);else messages.push(value)}});
 const next=()=>messages.length?Promise.resolve(messages.shift()):new Promise((resolve,reject)=>{listeners.push(v=>{socket.removeListener('error',reject);resolve(v)});socket.once('error',reject)});
 await next();let id=0;
 async function command(method,params={}){const message=JSON.stringify([0,++id,method,params]);socket.write(Buffer.byteLength(message)+':'+message);const result=await next();if(result[2])throw Error(JSON.stringify(result[2]));return result[3]}
 return {command,close:()=>socket.end()};
}
